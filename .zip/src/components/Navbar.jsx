import React from "react";
import { Box, Button,  } from "@mui/material";
import Menu from "./Menu"
// import { borders } from '@material-ui/system';
function Navbar() {
   
    let Home = [
      "Home One",
      "Home Two",
      "Home Three",
      "Home Four",
      "Home Five"
    ]

    let Sevices = [
      "Sevices",
      "Sevices Details"
      
  ]
  let About  = [
    "About Us"
  ]

  let Project = [
    "Project",
    "Project Details"
  ]

  let  Blog = [
    "Blog",
    "Blog Details"
  ]

  let Pages = [
    "Shop",
"Single Product",
"Cart",
"Checkout",
"Login",
"Contact Us",
"FAQ",
"404 Error"
  ]
  return (
    <>
      <Box
        border={"1px solid red"}
        padding={"20px 200px"}
        display={"flex"}
        alignItems={"center"}
        justifyContent={"space-between"}
      >
        <Box border={"1px solid black"}></Box>
        <Box border={"1px solid green"} display={"flex"}
        alignItems={"center"}
        justifyContent={"space-between"} gap={"20px"}>
            <Menu name="Home" section={Home} />

            <Menu name=" Sevices" section={ Sevices} />
            <Menu name=" About" section={About}/>
            <Menu name=" Project" section={Project}/>
            <Menu name="Blog" section={Blog}/>
            <Menu name="Pages" section={Pages}/>
            

        </Box>
        <Box>
          <Button
            sx={{ borderRadius: "40px" }}
            padding="0 35px"
            variant="contained"
          >
            Contact Us
          </Button>
        </Box>
      </Box>
    </>
  );
}

export default Navbar;
